# Data payload

Measurement data behind the paper "Energy-Aware Assessment and Energy Modeling for Encrypted Video KQI Prediction at the Edge". All files are verbatim copies of the originals in the thesis data repository (`data_masters_thesis/`), apart from the two `repro_*.csv` files, which were recomputed during the reproduction check. Every file is listed in `MANIFEST.csv` (repo path, source path relative to the project folder, byte size, SHA-256). Sizes below are exact bytes (MB = 10^6 bytes).

Workloads: **W1** = offline inference benchmark (a stored test set pushed through each model, energy metered per run); **W2** = live single-stream monitoring (capture, feature extraction and inference on a live stream); **W3** = packet-capture and dissection cost. Two devices appear throughout: `raspberry_pi` and `jetson_nano_orin`.

## Directory overview

| Directory | Content | Workload / stage | Original path in `data_masters_thesis/` | Files | Size |
|---|---|---|---|---|---|
| `w1_offline/{device}/{offline,offline_fixed_batch}/{kqi}/{view}/{family}/` | Energy, power, CPU/RAM utilisation and prediction scores for every selected model configuration, run on a stored test set. `offline` is the default batching, `offline_fixed_batch` a fixed batch size. | W1 | `measurements/model_execution/{device}/{offline,offline_fixed_batch}/` | 384 (192 per device) | 7.22 MB |
| `w2_live/{device}/live/{model_execution,feature_extraction,feature_extraction_ram,capturing_processing}/...` | Live monitoring runs: whole-pipeline stages for the live shortlist. `feature_extraction_ram` holds the corrected RAM figures (see below). `capturing_processing` exists for the Jetson only (2 files). | W2 | `measurements/model_execution/{device}/live/` | 147 (71 Pi, 76 Jetson) | 1.65 MB |
| `w3_capture/` | Packet capture and dissection cost per capture mode (`complete_capture`, `header_only`, `header_only_gt_100`, `header_only_uplink_only`, `header_only_uplink_only_gt_100`, `*_dissection` variants, `header_only_save_to_ram`/`_disk`). | W3 | `measurements/capturing/` | 173 | 2.00 MB |
| `feature_extraction/` | Cost of the feature-extraction stage, offline and live, per device. | Pipeline stage | `measurements/feature_extraction/` | 59 | 0.84 MB |
| `processing/` | Cost of the packet-processing stage (packets to elements). | Pipeline stage | `measurements/processing/` | 40 | 0.53 MB |
| `elementary_aggregation/` | Micro-benchmark of elementary aggregation operations (`diff`, `max`, `mean`, `median`, ...) across numeric dtypes (`float16/32/64`, `int16/32/64`). | Pipeline stage (micro-benchmark) | `measurements/elementary_aggregation/` | 120 | 1.44 MB |
| `idle/` | 12-hour idle-power baselines per device (JSON, includes the raw `tf_power_ts` series). | Reference for all workloads | `measurements/idle_baseline/` | 2 | 13.07 MB |
| `hpo/` | The 12 Optuna SQLite study databases (stalling and buffer health x cnn, ffnn, lgbm, lstm, rf, transformer). | Model selection | `measurements/model_hpo/` | 12 | 46.09 MB |
| `importances/` | Permutation-importance and MI importance JSONs used for feature selection. | Feature selection | `general_data/importances/` | 33 | 0.36 MB |
| `selected_models/` | Per-device live shortlists. | Live model selection | `general_data/selected_models/` | 16 | 0.02 MB |
| `derived/` | Metadata and recomputed aggregates (below). | Analysis inputs | see below | 13 | 3.97 MB |
| `features/` | Reserved for the feature documentation/name lists (maintained separately). | - | - | - | - |

Not copied: `measurements/model_training/` (not in scope of this payload).

Contents of `derived/`:

- From `general_data/other/`: `bh_stalling_prediction_stats.csv`, `dataset_window_stats.json`, `parameter_values.json`, `summary_statistics.json`, `trial_datasets.json`, `trial_sequence_sizes.json`, `trial_window_sizes.json`.
- From `general_data/model_complexity/`: `model_parameters.json`, `model_sizes.json`.
- `video_ids.csv`: the video identity of each of the 11,142 playback runs.
- `repro_scores.csv` (per-configuration AP, F1, R2, MAE recomputed from the raw prediction arrays, next to the values stored in the JSONs; `n` is the test population, `div128` flags batch truncation) and `repro_w1.csv` (per-configuration W1 energy aggregates: median-filtered mean energy `E`, number of runs `n`, outliers removed `nout`, 95 % CI half-width in percent, duration, scores, runtime, parameter count). Both were produced by the reproduction check, not by the original experiments; their source scripts live in `code/analysis/` (maintained separately).

## Measurement CSV schema

Each measurement CSV holds one row per repetition. W1 files (and nearly all others) have 30 repetitions (30 data rows). Exceptions: 47 of the W2 files have 5 repetitions, and 27 of the W3 `*_dissection` files have between 1 and 15 rows. Columns are grouped by prefix; the exact set varies with device and stage.

- `timestamp`, `config`: Unix start time and a run identifier of the form `{kqi}_{view}_{family}_{selection}_{rep}-{hash}`.
- `tf_*`: whole-device readings from the external Tinkerforge power meter: `tf_label`, `tf_duration` (s), `tf_power_avg/min/max` (W), `tf_energy_wh` (Wh) and `tf_energy` (J). `tf_energy` is the energy figure used in the paper.
- `ul_*`: utilisation readings of the measured process and the host: `ul_label`, `ul_duration`, `ul_ram_process_*` / `ul_ram_global_*` and `ul_cpu_process_*` / `ul_cpu_global_*` (each avg/min/max).
- `jn_*` (Jetson only): the Jetson's on-board sensors: `jn_total_power_*`, `jn_total_energy`, `jn_chip_power_*`, `jn_chip_energy`, `jn_fan_speed_*`, and for model runs also `jn_gpu_util_*`, `jn_vram_*`, `jn_ram_*`.
- W2/W3/feature-extraction/processing files additionally carry stream-injection counters (`actual`, `successful`, `failed`, `truncated`, `retried_enobufs`, `retried_eagain`) and stage counters (`captured_packets`, `dropped_packets`, `processed_elements`, `processed_packets`, `contained packets`, `total_input_elements`, `total_output_elements`, `predictions`).
- Trailing columns of W1 model files are the prediction scores for that configuration. Stalling (classifier): `tn, fp, fn, tp, accuracy, precision, recall, f1, f1_macro, mcc, ap, pr_auc, f1_threshold`. Buffer health (regressor): `average, median, mae, medae, rmse, r2`. Both end with `runtime` and `n_parameters`.

Files are organised as `{device}/{...}/{kqi}/{view}/{family}/{kqi}_{view}_{family}_{efficiency|performance}_stats.csv`, with views `all`, `gt_100`, `uplink_only`, `uplink_only_gt_100`.

### RAM-corrected feature-extraction variant

Following `data_masters_thesis/README.md`: for live feature extraction there is a second folder with suffix `_ram` (`w2_live/*/live/feature_extraction_ram/`) that contains corrected RAM measurements, because the original results also counted the model loaded into RAM. Use the `_ram` variant for RAM figures.

## Deliberately excluded (too large for git)

| Excluded | Size | Reason |
|---|---|---|
| `general_data/stalling_predictions/` | 165 MB (144 files) | raw per-sample prediction arrays |
| `general_data/buffer_health_predictions/` | 160 MB (144 files) | raw per-sample prediction arrays |
| `general_data/pcap_stats/` | 1.1 GB (122 files) | packet-capture statistics |
| `yt_dataset/` | 5.5 GB (22,284 files) | processed parquet version of the dataset |

The full dataset is the published YouTube dataset of Loh et al. (cited in the paper as `loh2022dataset`); it is not redistributed here. The excluded prediction arrays are what `repro_scores.csv` was computed from.

## Code modifications

Four deliberate changes were made to the carried-over code, all recorded here. Everything else
in `code/model/`, `code/baseline/` and `code/figures/` is byte-identical to the archive copies.

1. `code/model/energy_model.py` is the later of the two archived versions. The earlier one
   lacks the `live_residual` function that `audit.py` calls, so the audit entry point would
   fail with an `AttributeError` and could not regenerate the calibrated live offsets. The two
   differ only in the offset accounting.
2. `code/model/uncertainty.py` no longer writes a PNG copy of its figure to an absolute scratch
   directory on the authors' machine, which raised `FileNotFoundError` anywhere else after all
   results had already been written. It now writes the PNG beside the PDF.
3. `code/baseline/build_dataset.py` (line 9) and `code/baseline/timing.py` (line 5) had an
   absolute path to a local copy of the dataset. Both now hold the relative placeholder
   `yt_dataset/dataset`, which must be pointed at a copy of the published YouTube dataset of
   Loh et al. before running.
4. The helper scripts in `code/features/` and `notes/` fall back to a relative
   `data_masters_thesis/` path instead of an absolute one when the in-repository copy of a data
   directory is absent.
